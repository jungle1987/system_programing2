﻿#pragma once
#include "library.h"
#include <fstream>
#include "Student.h"


namespace CppCLRWinFormsProject {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	list<Student> list_Students;//vektorius talpins student objektus i list_students
	list<Student> list_sortas;
	vector<int>score_container;
	string eil;
	int generate_data_size = 0;
	int n = 0, m = 0;
	Student Temp_data;//perduodu i inputa
	int dataSize1 = 1000;
	int dataSize2 = 10000;
	int dataSize3 = 100000;
	int dataSize4 = 1000000;
	string generated_file = "kursiokai_grades_sugeneruota.txt";
	// nuolat pildomas list_students objektas

	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:

		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//

		}


	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Button^ button2;
	protected:
	private: System::Windows::Forms::Button^ button1;
	private: System::Windows::Forms::TextBox^ textBox1;
	private: System::Windows::Forms::SaveFileDialog^ saveFileDialog1;
	private: System::Windows::Forms::Button^ button3;
	private: System::String^ failo_vardas = "";
	private: System::Windows::Forms::OpenFileDialog^ openFileDialog1;
	private: System::Windows::Forms::Button^ button4;
	private: System::Windows::Forms::MenuStrip^ menuStrip1;
	private: System::Windows::Forms::ToolStripMenuItem^ menuToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^ openToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^ saveAsToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^ saveToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^ exitToolStripMenuItem;
	private: System::Windows::Forms::Button^ button5;
	private: System::Windows::Forms::ComboBox^ comboBox1;

	private: System::Windows::Forms::ToolStripMenuItem^ aboutToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^ infoToolStripMenuItem;
	private: System::Windows::Forms::Label^ label1;

	private: System::Windows::Forms::Button^ button6;
	private: System::Windows::Forms::Button^ button7;


	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container^ components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->button2 = (gcnew System::Windows::Forms::Button());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->textBox1 = (gcnew System::Windows::Forms::TextBox());
			this->saveFileDialog1 = (gcnew System::Windows::Forms::SaveFileDialog());
			this->button3 = (gcnew System::Windows::Forms::Button());
			this->openFileDialog1 = (gcnew System::Windows::Forms::OpenFileDialog());
			this->button4 = (gcnew System::Windows::Forms::Button());
			this->menuStrip1 = (gcnew System::Windows::Forms::MenuStrip());
			this->menuToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->openToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->saveAsToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->saveToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->exitToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->aboutToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->infoToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->button5 = (gcnew System::Windows::Forms::Button());
			this->comboBox1 = (gcnew System::Windows::Forms::ComboBox());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->button6 = (gcnew System::Windows::Forms::Button());
			this->button7 = (gcnew System::Windows::Forms::Button());
			this->menuStrip1->SuspendLayout();
			this->SuspendLayout();
			// 
			// button2
			// 
			this->button2->Location = System::Drawing::Point(534, 248);
			this->button2->Margin = System::Windows::Forms::Padding(2);
			this->button2->Name = L"button2";
			this->button2->Size = System::Drawing::Size(106, 25);
			this->button2->TabIndex = 1;
			this->button2->Text = L"Open";
			this->button2->UseVisualStyleBackColor = true;
			this->button2->Click += gcnew System::EventHandler(this, &Form1::button2_Click);
			// 
			// button1
			// 
			this->button1->Location = System::Drawing::Point(534, 343);
			this->button1->Margin = System::Windows::Forms::Padding(2);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(106, 25);
			this->button1->TabIndex = 2;
			this->button1->Text = L"Save";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &Form1::button1_Click);
			// 
			// textBox1
			// 
			this->textBox1->Location = System::Drawing::Point(16, 44);
			this->textBox1->Margin = System::Windows::Forms::Padding(2);
			this->textBox1->Multiline = true;
			this->textBox1->Name = L"textBox1";
			this->textBox1->ScrollBars = System::Windows::Forms::ScrollBars::Vertical;
			this->textBox1->Size = System::Drawing::Size(483, 406);
			this->textBox1->TabIndex = 3;
			this->textBox1->TextChanged += gcnew System::EventHandler(this, &Form1::textBox1_TextChanged);
			// 
			// saveFileDialog1
			// 
			this->saveFileDialog1->FileOk += gcnew System::ComponentModel::CancelEventHandler(this, &Form1::saveFileDialog1_FileOk);
			// 
			// button3
			// 
			this->button3->Location = System::Drawing::Point(534, 296);
			this->button3->Margin = System::Windows::Forms::Padding(2);
			this->button3->Name = L"button3";
			this->button3->Size = System::Drawing::Size(106, 25);
			this->button3->TabIndex = 4;
			this->button3->Text = L"Save as..";
			this->button3->UseVisualStyleBackColor = true;
			this->button3->Click += gcnew System::EventHandler(this, &Form1::button3_Click);
			// 
			// openFileDialog1
			// 
			this->openFileDialog1->FileName = L"openFileDialog1";
			this->openFileDialog1->FileOk += gcnew System::ComponentModel::CancelEventHandler(this, &Form1::openFileDialog1_FileOk);
			// 
			// button4
			// 
			this->button4->Location = System::Drawing::Point(534, 422);
			this->button4->Margin = System::Windows::Forms::Padding(2);
			this->button4->Name = L"button4";
			this->button4->Size = System::Drawing::Size(106, 25);
			this->button4->TabIndex = 5;
			this->button4->Text = L"Close";
			this->button4->UseVisualStyleBackColor = true;
			this->button4->Click += gcnew System::EventHandler(this, &Form1::button4_Click);
			// 
			// menuStrip1
			// 
			this->menuStrip1->ImageScalingSize = System::Drawing::Size(24, 24);
			this->menuStrip1->Items->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(2) {
				this->menuToolStripMenuItem,
					this->aboutToolStripMenuItem
			});
			this->menuStrip1->Location = System::Drawing::Point(0, 0);
			this->menuStrip1->Name = L"menuStrip1";
			this->menuStrip1->Padding = System::Windows::Forms::Padding(4, 1, 0, 1);
			this->menuStrip1->Size = System::Drawing::Size(691, 24);
			this->menuStrip1->TabIndex = 6;
			this->menuStrip1->Text = L"menuStrip1";
			// 
			// menuToolStripMenuItem
			// 
			this->menuToolStripMenuItem->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(4) {
				this->openToolStripMenuItem,
					this->saveAsToolStripMenuItem, this->saveToolStripMenuItem, this->exitToolStripMenuItem
			});
			this->menuToolStripMenuItem->Name = L"menuToolStripMenuItem";
			this->menuToolStripMenuItem->Size = System::Drawing::Size(50, 22);
			this->menuToolStripMenuItem->Text = L"Menu";
			this->menuToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::menuToolStripMenuItem_Click);
			// 
			// openToolStripMenuItem
			// 
			this->openToolStripMenuItem->Name = L"openToolStripMenuItem";
			this->openToolStripMenuItem->Size = System::Drawing::Size(118, 22);
			this->openToolStripMenuItem->Text = L"Open";
			this->openToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::openToolStripMenuItem_Click);
			// 
			// saveAsToolStripMenuItem
			// 
			this->saveAsToolStripMenuItem->Name = L"saveAsToolStripMenuItem";
			this->saveAsToolStripMenuItem->Size = System::Drawing::Size(118, 22);
			this->saveAsToolStripMenuItem->Text = L"Save as..";
			this->saveAsToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::saveAsToolStripMenuItem_Click);
			// 
			// saveToolStripMenuItem
			// 
			this->saveToolStripMenuItem->Name = L"saveToolStripMenuItem";
			this->saveToolStripMenuItem->Size = System::Drawing::Size(118, 22);
			this->saveToolStripMenuItem->Text = L"Save";
			this->saveToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::saveToolStripMenuItem_Click);
			// 
			// exitToolStripMenuItem
			// 
			this->exitToolStripMenuItem->Name = L"exitToolStripMenuItem";
			this->exitToolStripMenuItem->Size = System::Drawing::Size(118, 22);
			this->exitToolStripMenuItem->Text = L"Exit";
			this->exitToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::exitToolStripMenuItem_Click);
			// 
			// aboutToolStripMenuItem
			// 
			this->aboutToolStripMenuItem->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(1) { this->infoToolStripMenuItem });
			this->aboutToolStripMenuItem->Name = L"aboutToolStripMenuItem";
			this->aboutToolStripMenuItem->Size = System::Drawing::Size(52, 22);
			this->aboutToolStripMenuItem->Text = L"About";
			this->aboutToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::aboutToolStripMenuItem_Click);
			// 
			// infoToolStripMenuItem
			// 
			this->infoToolStripMenuItem->Name = L"infoToolStripMenuItem";
			this->infoToolStripMenuItem->Size = System::Drawing::Size(95, 22);
			this->infoToolStripMenuItem->Text = L"Info";
			this->infoToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::infoToolStripMenuItem_Click);
			// 
			// button5
			// 
			this->button5->Location = System::Drawing::Point(530, 109);
			this->button5->Margin = System::Windows::Forms::Padding(2);
			this->button5->Name = L"button5";
			this->button5->Size = System::Drawing::Size(106, 25);
			this->button5->TabIndex = 7;
			this->button5->Text = L"Generate file";
			this->button5->UseVisualStyleBackColor = true;
			this->button5->Click += gcnew System::EventHandler(this, &Form1::button5_Click);
			// 
			// comboBox1
			// 
			this->comboBox1->FormattingEnabled = true;
			this->comboBox1->Location = System::Drawing::Point(530, 66);
			this->comboBox1->Name = L"comboBox1";
			this->comboBox1->Size = System::Drawing::Size(121, 21);
			this->comboBox1->TabIndex = 8;
			this->comboBox1->SelectedIndexChanged += gcnew System::EventHandler(this, &Form1::comboBox1_SelectedIndexChanged);
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(531, 47);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(82, 13);
			this->label1->TabIndex = 10;
			this->label1->Text = L"Select data size";
			// 
			// button6
			// 
			this->button6->Location = System::Drawing::Point(530, 150);
			this->button6->Margin = System::Windows::Forms::Padding(2);
			this->button6->Name = L"button6";
			this->button6->Size = System::Drawing::Size(106, 25);
			this->button6->TabIndex = 12;
			this->button6->Text = L"Sort by Name";
			this->button6->UseVisualStyleBackColor = true;
			this->button6->Click += gcnew System::EventHandler(this, &Form1::button6_Click_1);
			// 
			// button7
			// 
			this->button7->Location = System::Drawing::Point(530, 196);
			this->button7->Name = L"button7";
			this->button7->Size = System::Drawing::Size(106, 25);
			this->button7->TabIndex = 13;
			this->button7->Text = L"Sort by Average";
			this->button7->UseVisualStyleBackColor = true;
			this->button7->Click += gcnew System::EventHandler(this, &Form1::button7_Click_1);
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(691, 501);
			this->Controls->Add(this->button7);
			this->Controls->Add(this->button6);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->comboBox1);
			this->Controls->Add(this->button5);
			this->Controls->Add(this->button4);
			this->Controls->Add(this->button3);
			this->Controls->Add(this->textBox1);
			this->Controls->Add(this->button1);
			this->Controls->Add(this->button2);
			this->Controls->Add(this->menuStrip1);
			this->MainMenuStrip = this->menuStrip1;
			this->Margin = System::Windows::Forms::Padding(2);
			this->Name = L"Form1";
			this->Text = L"Form1";
			this->Load += gcnew System::EventHandler(this, &Form1::Form1_Load);
			this->menuStrip1->ResumeLayout(false);
			this->menuStrip1->PerformLayout();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
		int generate_data_size;
#pragma endregion
	private: System::Void Form1_Load(System::Object^ sender, System::EventArgs^ e) {
		listingsInCombobox();
		button5->Enabled = false;
		button6->Enabled = false;
		button7->Enabled = false;
	}
	private: System::Void saveFileDialog1_FileOk(System::Object^ sender, System::ComponentModel::CancelEventArgs^ e) {

	}

	

	private: System::Void button2_Click(System::Object^ sender, System::EventArgs^ e) {
		openFileDialog1->InitialDirectory = "..\\";															// parenkome darbinę direktoriją
		openFileDialog1->Filter = "txt files (*.txt)|*.txt";												// naudojamas filtras "Text files (*.txt)|*.txt";
		openFileDialog1->InitialDirectory = "..\\";															// parenkome darbinę direktoriją
		if (openFileDialog1->ShowDialog() == System::Windows::Forms::DialogResult::OK)						// atidarom bilu pasirinkimo atverimui langa, 
		{

			System::IO::StreamReader^ sr = gcnew System::IO::StreamReader(openFileDialog1->FileName);		// susiejame skaitymo srautą su atvertu failu kurio kelias
			// paimtas iš openFileDialog1->FileName
			textBox1->Text = (sr->ReadToEnd());																// nuskaitome į textBox1->Text tekstą iš atverto failo
			failo_vardas = openFileDialog1->FileName;														// išsaugome failo vardą jei noresime perrašyti jo turinį po pataisymų 
			sr->Close();																					// uždarome srautą ir failą
		}
	}
	private: System::Void openFileDialog1_FileOk(System::Object^ sender, System::ComponentModel::CancelEventArgs^ e) {
	}

	private: System::Void button3_Click(System::Object^ sender, System::EventArgs^ e) {
		SaveFileDialog^ saveFileDialog1 = gcnew SaveFileDialog();											// įgaliname įkeltą SaveFileDialog objektą
		saveFileDialog1->InitialDirectory = "..\\";															// parenkome darbinę direktoriją
		saveFileDialog1->Filter = "txt files (*.txt)|*.txt";												// parinkome galimus failų pletinius
		String^ z = textBox1->Text;																			// užpildome objektą System::String tekstu paimtu iš textBox1 objekto
	rep:
		if (saveFileDialog1->ShowDialog() == System::Windows::Forms::DialogResult::OK)						// atidarom saugojimo vietos pasirinkimo langa, 
			// naudojamas filtras "Text files (*.txt)|*.txt";
		{
			System::IO::StreamWriter^ sw = gcnew System::IO::StreamWriter(saveFileDialog1->FileName);	// susiejame įrašimo srautą su atvertu failu kurio kelias
			// paimtas iš saveFileDialog1->FileName
			sw->Write(z);																				// Įrašome textBox1->Text lauko tekstą į atvertą failą
			sw->Close();																				// uždarome srautą ir failą 
		}
		else MessageBox::Show("Error on file input", "Error", MessageBoxButtons::OK);						// pranešimas sapie klaidą, išveda pranešimą, 
		// užvardintą kaip "Error" su mygtuku OK


	}
	private: System::Void button1_Click(System::Object^ sender, System::EventArgs^ e) {
		String^ z;
		if (textBox1->Text == "") z = " ";																	// tikriname ar textBox1->Text nera tuščias ir jei taip įrašome į jį tarpą
		else z = textBox1->Text;
		if (failo_vardas != "")																				// tikriname ar prieš tai atvertas failas egzistuoja ar ne
		{
			System::IO::StreamWriter^ sw = gcnew System::IO::StreamWriter(failo_vardas);					// susiejame įrašimo srautą su atvertu failu kurio kelias saugomas failo_vardas 
			sw->Write(z);																					// Įrašome textBox1->Text lauko tekstą į atvertą failą
			sw->Close();																					// uždarome srautą ir failą
			MessageBox::Show("The file has been successfully\nrewritten",									// pranešimas apie sekmingą perrašimą, išveda pranešimą, 
				"Information", MessageBoxButtons::OK);														// užvardintą kaip "Information" su mygtuku OK
		}
		else MessageBox::Show("You forgot open file", "File open Error", MessageBoxButtons::OK);			// pranešimas apie klaidą, išveda pranešimą, 
		//užvardintą kaip "File open Error" su mygtuku OK

	}
	private: System::Void button4_Click(System::Object^ sender, System::EventArgs^ e) {
		Form1::Close();
	}
	private: System::Void textBox1_TextChanged(System::Object^ sender, System::EventArgs^ e) {

	}
	private: System::Void openToolStripMenuItem_Click(System::Object^ sender, System::EventArgs^ e) {
		button2_Click(sender, e);
	}
	private: System::Void saveAsToolStripMenuItem_Click(System::Object^ sender, System::EventArgs^ e) {
		button3_Click(sender, e);
	}
	private: System::Void menuToolStripMenuItem_Click(System::Object^ sender, System::EventArgs^ e) {
	}
	private: System::Void saveToolStripMenuItem_Click(System::Object^ sender, System::EventArgs^ e) {
		button1_Click(sender, e);
	}
	private: System::Void exitToolStripMenuItem_Click(System::Object^ sender, System::EventArgs^ e) {
		button4_Click(sender, e);
	}

	private: void outputResults(int size) {
		ofstream out_f("kursiokai_grades_apskaiciuota.txt");
		out_f << setw(15) << left << "Name" << setw(15) << left << "Surname" << setw(15) << left << "Average" << setw(15) << left << "Average Median" << "\n";
		for (std::list<Student>::iterator it = list_Students.begin(); it != list_Students.end(); ++it)
		{
			out_f << ' ' << *it;
		}
		out_f.close();		
	}

	private: void sortByName() {
		
		ofstream out_f_sort("sort_apskaiciuota.txt");
			out_f_sort << setw(15) << left << "Name" << setw(15) << left << "Surname" << setw(15) << left << "Average" << setw(15) << left << "Average Median" << "\n";
			list_Students.sort(sortName);
			for (std::list<Student>::iterator it = list_Students.begin(); it != list_Students.end(); ++it) 
			{
				out_f_sort << ' ' << *it;
			}
			out_f_sort.close();
			textBox1->Text = System::IO::File::ReadAllText("sort_apskaiciuota.txt");			
	}

	private: void sortByAverage() {
		ofstream out_f_sort("sort_apskaiciuota.txt");
		out_f_sort << setw(15) << left << "Name" << setw(15) << left << "Surname" << setw(15) << left << "Average" << setw(15) << left << "Average Median" << "\n";
		list_Students.sort(sortAverage);
		for (std::list<Student>::iterator it = list_Students.begin(); it != list_Students.end(); ++it)
		{
			out_f_sort << ' ' << *it;
		}
		out_f_sort.close();
		textBox1->Text = System::IO::File::ReadAllText("sort_apskaiciuota.txt");
	}

	private: void calculateResults(int size, string fileNameGenerated) {
		
		ifstream open_f(fileNameGenerated);
		getline(open_f, eil);
		for (int i = 0; i <= size; i++) {
			open_f >> Temp_data;
			list_Students.push_back(Temp_data);
			list_sortas.push_back(Temp_data);
			Temp_data.deleteStudentScores();
		}
		open_f.close();
		textBox1->Text = System::IO::File::ReadAllText("kursiokai_grades_sugeneruota.txt");
	}
	private: void generateDataSize(int size, string fileNameGenerated) {

		std::ofstream file_names(fileNameGenerated);

		for (int i = 0; i < size; i++) {
			file_names << "Vardas" << i + 1 << "\tPavarde" << i + 1 << "\t";
			for (int j = 0; j < 5; j++)
				file_names << 1 + (rand() % 9) << "\t";
			file_names << 1 + (rand() % 9) << std::endl;
		}
		file_names.close();
	}

	private: System::Void button5_Click(System::Object^ sender, System::EventArgs^ e) {
			
		button6->Enabled = true;
		button7->Enabled = true;
			if (comboBox1->SelectedIndex == 0) {

				generateDataSize(dataSize1, generated_file);
				calculateResults(dataSize1, generated_file);
				outputResults(dataSize1);
			}
			else if (comboBox1->SelectedIndex == 1) {
				generateDataSize(dataSize2, generated_file);
				calculateResults(dataSize2, generated_file);
				outputResults(dataSize2);
			}
			else if (comboBox1->SelectedIndex == 2) {
				generateDataSize(dataSize3, generated_file);
				calculateResults(dataSize3, generated_file);
				outputResults(dataSize3);
			}
			else if (comboBox1->SelectedIndex == 3) {
				generateDataSize(dataSize4, generated_file);
				calculateResults(dataSize4, generated_file);
				outputResults(dataSize4);
			}
	}

	private: void listingsInCombobox()
	{
		comboBox1->Items->Add("1000 rows");
		comboBox1->Items->Add("10000 rows");
		comboBox1->Items->Add("100000 rows");
		comboBox1->Items->Add("1000000 rows");

	}

	private: System::Void comboBox1_SelectedIndexChanged(System::Object^ sender, System::EventArgs^ e) {
		button5->Enabled = true;
		
	}
	private: System::Void button6_Click(System::Object^ sender, System::EventArgs^ e) {


	}
	private: System::Void aboutToolStripMenuItem_Click(System::Object^ sender, System::EventArgs^ e) {
	}

	private: System::Void infoToolStripMenuItem_Click(System::Object^ sender, System::EventArgs^ e) {
		MessageBox::Show("Karolis Kregzde", "PIT-NT-I-21");
	}

	private: System::Void vScrollBar1_Scroll(System::Object^ sender, System::Windows::Forms::ScrollEventArgs^ e) {
	}



	private: System::Void button6_Click_1(System::Object^ sender, System::EventArgs^ e) {
		
		sortByName();
	}

    private: System::Void button7_Click_1(System::Object^ sender, System::EventArgs^ e) {
		
		sortByAverage();
	}
	};
}
