#pragma once
#include <iostream>
#include <iomanip>
#include <string>
#include <vector>
#include <numeric>
#include <algorithm>
#include <ios>
#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include <sstream> 
#include <random>
#include <chrono>
#include <list>
#include<deque>

using std::cout;
using std::cin;
using std::string;
using std::vector;
using std::endl;
using std::left;
using std::setw;
using std::setprecision;
using std::fixed;
using std::showpoint;
using std::stringstream;
using std::ofstream;
using std::ifstream;
using std::istream_iterator;
using::std::list;
